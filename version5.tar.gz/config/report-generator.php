<?php

return [
    'flush' => false,
    'pdfLibrary' => 'dompdf' // snappy, dompdf : composer require barryvdh/laravel-dompdf
];
