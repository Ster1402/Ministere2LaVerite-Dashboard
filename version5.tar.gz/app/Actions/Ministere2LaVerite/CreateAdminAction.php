<?php


namespace App\Actions\Ministere2LaVerite;

use App\Models\User;

class CreateAdminAction
{
    public function execute(User $user, array $rolesNames): void
    {
//        ddd('CreateAdminAction', $user, $rolesNames);
    }
}
