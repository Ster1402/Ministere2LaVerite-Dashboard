<?php


namespace App\DTOs;

class SearchAdminDTO
{
    public string $userFilter;
    public array $rolesFilters;
}
