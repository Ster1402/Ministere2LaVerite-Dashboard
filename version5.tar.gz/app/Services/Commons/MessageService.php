<?php

namespace App\Services\Commons;

class MessageService
{
    public static string $TWILIO = 'twilio';
    public static string $NEXAH = 'nexah';
}
